// content.js — roda no contexto do WhatsApp Web
// Mantém um canal aberto para receber mensagens de volta do CRM (se necessário)
// e injeta um badge visual quando a extração for concluída

(function () {
  if (window.__evoCRMInjected) return;
  window.__evoCRMInjected = true;

  // Aguarda mensagem do popup confirmando extração (feedback visual opcional)
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'EXTRACAO_OK') {
      // Toast no WA Web
      const toast = document.createElement('div');
      toast.style.cssText = `
        position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
        background: #10b981; color: white; padding: 10px 20px;
        border-radius: 20px; font-size: 14px; font-weight: 600;
        z-index: 99999; box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        pointer-events: none; transition: opacity .4s;
      `;
      toast.textContent = `✅ ${msg.total} contato(s) capturado(s) pelo EvoCRM!`;
      document.body.appendChild(toast);
      setTimeout(() => { toast.style.opacity = '0'; }, 2500);
      setTimeout(() => { toast.remove(); }, 3000);
    }
  });
})();
