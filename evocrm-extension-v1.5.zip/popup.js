// EvoCRM Extrator — popup.js v1.5

let contatos = [];

const status      = document.getElementById('status');
const lista       = document.getElementById('lista');
const countLabel  = document.getElementById('countLabel');
const secExtract  = document.getElementById('section-extract');
const secList     = document.getElementById('section-list');
const secConfig   = document.getElementById('section-config');

function showStatus(msg, tipo = 'info') {
  status.textContent = msg;
  status.className = tipo;
  status.style.display = 'block';
  if (tipo === 'ok') setTimeout(() => status.style.display = 'none', 4000);
}

function renderLista() {
  lista.innerHTML = '';
  countLabel.textContent = `${contatos.length} contato${contatos.length !== 1 ? 's' : ''}`;
  contatos.forEach((c, i) => {
    const div = document.createElement('div');
    div.className = 'contact-item';
    const letra = (c.nome || 'C').charAt(0).toUpperCase();
    div.innerHTML = `
      <div class="avatar">${letra}</div>
      <div class="contact-info">
        <div class="contact-name">${c.nome}</div>
        <div class="contact-num">${c.numero}</div>
      </div>
      <button class="remove-btn" data-i="${i}" title="Remover">✕</button>
    `;
    lista.appendChild(div);
  });
  lista.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      contatos.splice(parseInt(btn.dataset.i), 1);
      renderLista();
      if (contatos.length === 0) { secList.style.display = 'none'; secExtract.style.display = 'flex'; }
    });
  });
  secList.style.display = contatos.length > 0 ? 'flex' : 'none';
}

async function executarExtracao() {
  showStatus('Extraindo contatos...', 'info');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes('web.whatsapp.com')) {
    showStatus('⚠️ Abra o WhatsApp Web primeiro!', 'erro');
    return;
  }
  let results;
  try {
    results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extrairContatosWA });
  } catch (e) {
    showStatus('Erro ao executar o script: ' + e.message, 'erro');
    return;
  }
  const resultado = results?.[0]?.result;
  if (!resultado || resultado.erro) {
    showStatus(resultado?.erro || 'Erro desconhecido.', 'erro');
    return;
  }
  const jaExiste = new Set(contatos.map(c => c.numero));
  let novos = 0;
  for (const c of resultado.contatos) {
    if (!jaExiste.has(c.numero)) { contatos.push(c); jaExiste.add(c.numero); novos++; }
  }
  showStatus(`✅ ${novos} novo(s) adicionado(s). Total: ${contatos.length}`, 'ok');
  secExtract.style.display = 'none';
  renderLista();
}

document.getElementById('btnExtrair').addEventListener('click', executarExtracao);
document.getElementById('btnExtrairMais').addEventListener('click', executarExtracao);

document.getElementById('btnEnviar').addEventListener('click', async () => {
  if (contatos.length === 0) { showStatus('Nenhum contato para enviar.', 'erro'); return; }
  try {
    const ch = new BroadcastChannel('evocrm_extractor');
    ch.postMessage({ contatos });
    ch.close();
    showStatus(`✅ ${contatos.length} contatos enviados! Verifique a aba do EvoCRM.`, 'ok');
  } catch (e) { showStatus('Erro ao enviar: ' + e.message, 'erro'); }
});

document.getElementById('btnExportCSV').addEventListener('click', () => {
  if (contatos.length === 0) return;
  const csv = 'Nome,Numero\n' + contatos.map(c => `"${c.nome}","${c.numero}"`).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'contatos_evocrm.csv'; a.click();
  URL.revokeObjectURL(url);
  showStatus(`✅ CSV exportado com ${contatos.length} contato(s).`, 'ok');
});

document.getElementById('btnLimpar').addEventListener('click', () => {
  contatos = []; renderLista();
  secExtract.style.display = 'flex';
  status.style.display = 'none';
});

document.getElementById('btnConfig').addEventListener('click', async () => {
  const { crmUrl } = await chrome.storage.local.get('crmUrl');
  document.getElementById('inputUrl').value = crmUrl || '';
  secConfig.style.display = secConfig.style.display === 'flex' ? 'none' : 'flex';
});

document.getElementById('btnSalvar').addEventListener('click', async () => {
  const url = document.getElementById('inputUrl').value.trim().replace(/\/$/, '');
  if (!url) { showStatus('Digite a URL do CRM.', 'erro'); return; }
  await chrome.storage.local.set({ crmUrl: url });
  secConfig.style.display = 'none';
  showStatus('✅ URL salva!', 'ok');
});

// =============================================================================
// FUNÇÃO INJETADA NO WHATSAPP WEB — v1.5
// Estratégia: JIDs via React fiber (fonte mais confiável do WA Web)
// =============================================================================
function extrairContatosWA() {

  function normNum(raw) {
    const d = raw.replace(/\D/g, '');
    if (d.length === 10 || d.length === 11) return '55' + d;
    if (d.length === 12 || d.length === 13) return d;
    if (d.length > 13) return '55' + d.slice(-11);
    return null;
  }

  function isNome(txt) {
    return txt && /[A-Za-zÀ-ÿ]{2}/.test(txt) && txt.length >= 2 && txt.length <= 80 &&
           !/http|www\.|@|\.com|\.br|whatsapp|\d{5}/i.test(txt);
  }

  // Lê props/state do React Fiber de um elemento DOM
  function getFiberProps(el) {
    if (!el) return null;
    const key = Object.keys(el).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
    if (!key) return null;
    let fiber = el[key];
    // Sobe no fiber para achar props com dados de contato
    for (let i = 0; i < 30 && fiber; i++) {
      const p = fiber.memoizedProps || fiber.pendingProps || {};
      if (p && (p.jid || p.id || (p.contact && p.contact.id))) return p;
      fiber = fiber.return;
    }
    return null;
  }

  // Extrai JID de string "@c.us"
  function jidParaNumero(jid) {
    if (!jid || !jid.includes('@c.us')) return null;
    return normNum(jid.replace(/@c\.us.*/, ''));
  }

  const contatos = [];
  const seen = new Set();

  // ── ESTRATÉGIA 1: React Fiber nos elementos do painel ───────────────────
  // Pega todos os elementos que possam ser itens de lista de participantes
  // Inclui qualquer li, div com role listitem, etc — mas lê o JID via fiber
  const candidatos = [
    ...document.querySelectorAll('[role="listitem"], [data-testid*="cell"], [data-id*="@c.us"], [data-jid*="@c.us"]')
  ];

  // Também tenta via fiber em spans de nome (título do participante)
  const spansTitulo = [...document.querySelectorAll('span[title]')].filter(s => {
    const t = s.getAttribute('title') || '';
    return t.length > 1 && t.length < 80;
  });

  for (const el of [...candidatos, ...spansTitulo]) {
    // Tenta data-id / data-jid direto no elemento
    const jidAttr = el.getAttribute('data-id') || el.getAttribute('data-jid') || '';
    if (jidAttr.includes('@c.us')) {
      const n = jidParaNumero(jidAttr);
      if (n && !seen.has(n)) {
        seen.add(n);
        const nomeEl = el.querySelector('span[title], span[dir="auto"]') || el;
        const nome = (nomeEl.getAttribute('title') || nomeEl.textContent || '').trim();
        contatos.push({ nome: isNome(nome) ? nome : 'Contato', numero: n });
        continue;
      }
    }

    // Tenta React fiber
    const props = getFiberProps(el);
    if (props) {
      const jid = props.jid || props.id || (props.contact && (props.contact.jid || props.contact.id)) || '';
      const n = jidParaNumero(jid);
      if (n && !seen.has(n)) {
        seen.add(n);
        const nome = props.name || props.pushname || props.notify || (props.contact && props.contact.name) || 'Contato';
        contatos.push({ nome: isNome(nome) ? nome : 'Contato', numero: n });
      }
    }
  }

  // ── ESTRATÉGIA 2: Varrer a store do WhatsApp (window.Store) ─────────────
  // O WA Web expõe window.Store em versões anteriores; em versões novas
  // fica em módulos webpack. Tentamos acessar via require/modules.
  if (contatos.length === 0) {
    try {
      // Tenta achar o módulo de grupo ativo
      const webpackModules = window.require ? window.require.m || {} : {};
      // Outra forma: módulo definido em webpackChunkbuild
      let grupoAtivo = null;
      try {
        const chatStore = window.require('WAWebChatStore') || window.require('@waweb/store');
        grupoAtivo = chatStore && chatStore.activeChat && chatStore.activeChat.get ? chatStore.activeChat.get() : null;
      } catch(e) {}

      if (grupoAtivo && grupoAtivo.groupMetadata && grupoAtivo.groupMetadata.participants) {
        grupoAtivo.groupMetadata.participants.forEach(p => {
          const n = jidParaNumero(p.id._serialized || p.id);
          if (n && !seen.has(n)) {
            seen.add(n);
            contatos.push({ nome: p.contact && p.contact.name ? p.contact.name : 'Contato', numero: n });
          }
        });
      }
    } catch(e) {}
  }

  // ── ESTRATÉGIA 3: Scan da DOM restrito ao painel visível ─────────────────
  // Encontra o painel mais à direita que esteja visível na tela
  if (contatos.length === 0) {
    // O painel de info fica sempre no lado direito da tela
    // Pega todos os painéis de nível alto e filtra pelo mais à direita
    const paineis = [...document.querySelectorAll('#app section, #app > div > div > div')].filter(el => {
      const r = el.getBoundingClientRect();
      return r.width > 200 && r.height > 300 && r.right > window.innerWidth * 0.5;
    });

    // Ordena pelo mais à direita
    paineis.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
    const painel = paineis[0];

    if (painel) {
      // Dentro do painel, busca spans com números de telefone
      const spans = [...painel.querySelectorAll('span')];
      for (const s of spans) {
        const t = (s.textContent || '').trim();
        const d = t.replace(/\D/g, '');
        if (d.length < 10 || d.length > 14) continue;
        const clean = t.replace(/[\s\-\+\.\(\)]/g, '');
        if (d.length < Math.floor(clean.length * 0.55)) continue;
        const n = normNum(d);
        if (!n || seen.has(n)) continue;
        seen.add(n);

        // Busca nome no ancestral
        let nome = null;
        let par = s.parentElement;
        for (let i = 0; i < 5 && par && par !== painel; i++) {
          const sts = [...par.querySelectorAll('span[title], span[dir="auto"]')];
          for (const st of sts) {
            const tt = (st.getAttribute('title') || st.textContent || '').trim();
            if (tt && tt !== t && isNome(tt) && tt.replace(/\D/g,'').length < 5) { nome = tt; break; }
          }
          if (nome) break;
          par = par.parentElement;
        }
        contatos.push({ nome: nome || 'Contato', numero: n });
      }
    }
  }

  // ── ESTRATÉGIA 4: Busca por spans com número de telefone em TODA a tela ──
  // mas exclui a lista de conversas (lado esquerdo, x < 33% da tela)
  if (contatos.length === 0) {
    const larguraTela = window.innerWidth;
    const allSpans = [...document.querySelectorAll('span[dir="auto"], span[title]')];

    for (const s of allSpans) {
      const rect = s.getBoundingClientRect();
      // Só considera elementos no lado direito da tela (painel de info)
      if (rect.left < larguraTela * 0.33) continue;

      const t = (s.textContent || s.getAttribute('title') || '').trim();
      const d = t.replace(/\D/g, '');
      if (d.length < 10 || d.length > 14) continue;
      const clean = t.replace(/[\s\-\+\.\(\)]/g, '');
      if (d.length < Math.floor(clean.length * 0.55)) continue;

      const n = normNum(d);
      if (!n || seen.has(n)) continue;
      seen.add(n);

      let nome = null;
      let par = s.parentElement;
      for (let i = 0; i < 5 && par; i++) {
        const sts = [...par.querySelectorAll('span[title], span[dir="auto"]')];
        for (const st of sts) {
          const tt = (st.getAttribute('title') || st.textContent || '').trim();
          if (tt && tt !== t && isNome(tt) && tt.replace(/\D/g,'').length < 4) { nome = tt; break; }
        }
        if (nome) break;
        par = par.parentElement;
      }
      contatos.push({ nome: nome || 'Contato', numero: n });
    }
  }

  if (contatos.length === 0) {
    return {
      erro: '⚠️ Nenhum participante encontrado.\n\nCertifique-se de:\n1. Clicar no nome do grupo\n2. Rolar a lista de participantes até o final\n3. Tentar novamente'
    };
  }

  return { contatos };
}
